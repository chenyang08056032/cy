# SPDX-License-Identifier: Apache-2.0
"""Bit-exact fused RMSNorm + adaLN scale/shift (optionally with a preceding
residual-gate add) for bf16 activations.

Replaces the eager ERNIE-Image adaLN chain

    ``norm(x) * (1 + scale) + shift``                    (4 kernels)
    ``res = residual + gate * update`` before the norm   (+1 kernel)

with one Triton kernel per site while reproducing the eager chain's rounding
*bit for bit* (``torch.equal``), so it can be wired unconditionally (no
quality gate), unlike a plain fp32 single-pass fusion which perturbs the
50-step denoising trajectory (T8: PSNR 18.83 dB at quality=high).

Numerics contract (each step matches the eager kernel boundary):

- ``RMSNorm.forward_cuda`` dispatches to ``sgl_kernel.rmsnorm`` ->
  flashinfer's CuTe-DSL ``RMSNormKernel``.  For contiguous bf16 rows with
  ``H == 64 * threads_per_row`` (threads_per_row 32 for H<=3072 else 64,
  cluster_n == 1) that kernel computes, per row:

  * thread ``tx`` owns columns ``{8*tpr*b + 8*tx + v : b, v in [0,8)}``;
    its fragment is ordered ``v`` fastest, then ``b``;
  * ``x_sq = x * x`` in fp32 (each square rounded separately, no FMA), then
    an *ordered* sequential fadd chain over the 64 fragment values
    (MLIR ``vector.reduction`` without reassoc);
  * warp reduction via ``shfl.bfly`` with offsets 1,2,4,8,16 == an
    adjacent-pairs fold tree; two warp sums are then added (tpr == 64);
  * ``rstd = rsqrt.approx.f32(sum_sq / H + eps)`` (``cute.math.rsqrt``
    with fastmath);
  * ``y = (bf16)(float(x) * rstd * (w + 0.0))`` -- one final rounding.

- The aten modulate chain rounds to bf16 after every op (fp32 opmath):
  ``round(1 + scale)``, ``round(y * that)``, ``round(prod + shift)``.

- The residual variant reproduces the eager pair ``round(gate * update)``,
  ``round(residual + that)`` (identical to ``residual_gate_add_cuda``) and
  feeds the rounded result into the same faithful norm.

The per-fragment chain is expressed as 64 ordered adds over (TPR,)-wide
strided loads, the fold trees with ``tl.reshape``/``tl.split`` (order-exact,
single adds), bf16 boundaries with a bitcast round-to-nearest-even helper,
and the square with an opaque ``mul.rn.f32`` so the compiler cannot contract
it into an FMA.  Verified ``torch.equal`` against the live eager chain on
(1,4216,4096)/(1,4096,4096)/(2,1140,4096)/(1,128,2048) bf16; callers should
still verify once at runtime and fall back if the platform's rmsnorm dispatch
ever changes (see ``ernie_image.py``).
"""

from __future__ import annotations

from typing import Tuple

import torch
import triton  # type: ignore
import triton.language as tl  # type: ignore

from sglang.kernels.numerics import (
    mul_rn_f32,
    round_bf16_to_fp32,
    rsqrt_approx_f32,
)
from sglang.kernels.ops.diffusion.common.platform import is_cuda
from sglang.srt.utils.custom_op import register_custom_op


@triton.jit
def _fold_adjacent(p, rows: tl.constexpr, width: tl.constexpr):
    # (rows, 2*width) -> (rows, width): add adjacent pairs (even + odd), the
    # tree a shfl butterfly with the smallest offset first produces.
    a, b = tl.split(tl.reshape(p, (rows, width, 2)))
    return a + b


@triton.jit
def _rmsnorm_scale_shift_kernel(
    out_ptr,
    res_out_ptr,
    x_ptr,  # norm input (no gate) / update (with gate)
    residual_ptr,
    gate_ptr,
    weight_ptr,
    scale_ptr,
    shift_ptr,
    seq_len,
    eps,
    D: tl.constexpr,
    TPR: tl.constexpr,
    WPR: tl.constexpr,
    HAS_GATE: tl.constexpr,
):
    row = tl.program_id(0).to(tl.int64)
    batch = row // seq_len
    row_base = row * D
    vec_base = batch * D

    # ----- pass 1: sum of squares in the exact CuTe reduction order -----
    # "thread" tx of the replicated kernel owns columns 8*TPR*b + 8*tx + v;
    # its fragment is iterated v fastest, then b, as one ordered fadd chain
    # (each square separately rounded, no FMA).
    tx = tl.arange(0, TPR) * 8
    acc = tl.zeros((TPR,), dtype=tl.float32)
    for b in tl.static_range(8):
        for v in tl.static_range(8):
            col = tx + (b * 8 * TPR + v)
            if HAS_GATE:
                rj = tl.load(residual_ptr + row_base + col).to(tl.float32)
                uj = tl.load(x_ptr + row_base + col).to(tl.float32)
                gj = tl.load(gate_ptr + vec_base + col).to(tl.float32)
                # eager pair: bf16 round after gate*update and after the add
                xj = round_bf16_to_fp32(rj + round_bf16_to_fp32(gj * uj))
            else:
                xj = tl.load(x_ptr + row_base + col).to(tl.float32)
            acc = acc + mul_rn_f32(xj, xj)

    # warp butterfly (offsets 1,2,4,8,16) == adjacent-pairs fold tree,
    # then the WPR warp sums are combined the same way.
    p = tl.reshape(acc, (WPR, 32))
    p = _fold_adjacent(p, WPR, 16)
    p = _fold_adjacent(p, WPR, 8)
    p = _fold_adjacent(p, WPR, 4)
    p = _fold_adjacent(p, WPR, 2)
    p = _fold_adjacent(p, WPR, 1)
    s = tl.reshape(p, (1, WPR))
    if WPR == 2:
        s = _fold_adjacent(s, 1, 1)
    rcp = tl.sum(rsqrt_approx_f32(s / D + eps))  # single element, exact

    # ----- pass 2: normalize + modulate, contiguous chunks -----
    for i in tl.static_range(D // 1024):
        cols = i * 1024 + tl.arange(0, 1024)
        if HAS_GATE:
            r = tl.load(residual_ptr + row_base + cols).to(tl.float32)
            u = tl.load(x_ptr + row_base + cols).to(tl.float32)
            g = tl.load(gate_ptr + vec_base + cols).to(tl.float32)
            xin = round_bf16_to_fp32(r + round_bf16_to_fp32(g * u))
            tl.store(res_out_ptr + row_base + cols, xin)
        else:
            xin = tl.load(x_ptr + row_base + cols).to(tl.float32)
        w = tl.load(weight_ptr + cols).to(tl.float32)
        sc = tl.load(scale_ptr + vec_base + cols).to(tl.float32)
        sh = tl.load(shift_ptr + vec_base + cols).to(tl.float32)
        y = round_bf16_to_fp32(xin * rcp * w)  # (bf16)(x * rstd * w)
        one_plus = round_bf16_to_fp32(1.0 + sc)
        prod = round_bf16_to_fp32(y * one_plus)
        tl.store(out_ptr + row_base + cols, prod + sh)  # store rounds to bf16


def _threads_per_row(hidden: int) -> int | None:
    # mirror of flashinfer RMSNormKernel._compute_threads_per_row for the
    # regime this kernel replicates (one 8-wide vector per (thread, block))
    tpr = 32 if hidden <= 3072 else 64 if hidden <= 6144 else None
    if tpr is None or hidden != 64 * tpr:
        return None
    return tpr


def _is_row_broadcast(t: torch.Tensor, shape: tuple, device: torch.device) -> bool:
    return (
        t.dtype is torch.bfloat16
        and t.device == device
        and t.shape == shape
        and t.is_contiguous()
    )


def can_use_fused_rmsnorm_modulation(
    x: torch.Tensor, scale: torch.Tensor, shift: torch.Tensor
) -> bool:
    """Whether this kernel can serve ``x`` with this ``scale``/``shift``.

    The launcher raises on everything it cannot serve, which is the right
    answer for a caller that has already committed. A request-gated caller has
    not: a fast path that meets an input it cannot handle has to fall back,
    not fail the request. So it asks here first, and this mirrors exactly what
    :func:`_validate_rmsnorm_modulate` checks about ``x`` and the modulation
    rows -- a dtype-and-width check alone leaves the layout of ``scale`` and
    ``shift`` to chance.
    """
    if not (
        can_use_fused_rmsnorm_scale_shift(x.dtype, x.shape[-1])
        and x.is_cuda
        and x.ndim == 3
        and x.is_contiguous()
    ):
        return False
    row_shape = (x.shape[0], 1, x.shape[-1])
    return _is_row_broadcast(scale, row_shape, x.device) and _is_row_broadcast(
        shift, row_shape, x.device
    )


def can_use_fused_rmsnorm_scale_shift(dtype: torch.dtype, hidden: int) -> bool:
    """Select the BF16 FlashInfer reduction replicated by this kernel."""
    return (
        is_cuda() and dtype is torch.bfloat16 and _threads_per_row(hidden) is not None
    )


def _validate_rmsnorm_modulate(x, weight, scale, shift) -> tuple[int, int, int, int]:
    shape = x.shape
    if not (
        is_cuda()
        and x.is_cuda
        and x.dtype is torch.bfloat16
        and len(shape) == 3
        and x.is_contiguous()
    ):
        raise RuntimeError(
            "RMSNorm modulation expects contiguous BF16 CUDA [B, S, D], D in (2048, 4096)"
        )
    batch, seq_len, hidden = shape
    tpr = _threads_per_row(hidden)
    if tpr is None:
        raise RuntimeError("RMSNorm modulation requires D in (2048, 4096)")
    device = x.device
    if not (
        weight.dtype is torch.bfloat16
        and weight.device == device
        and weight.shape == (hidden,)
        and weight.is_contiguous()
    ):
        raise RuntimeError(
            "weight must be a contiguous [D] vector matching x's dtype/device"
        )
    row_shape = (batch, 1, hidden)
    if not (
        _is_row_broadcast(scale, row_shape, device)
        and _is_row_broadcast(shift, row_shape, device)
    ):
        raise RuntimeError(
            "scale and shift must be contiguous [B, 1, D] tensors matching x's dtype/device"
        )
    return batch, seq_len, hidden, tpr


def _fake_norm_scale_shift(
    x: torch.Tensor,
    weight: torch.Tensor,
    scale: torch.Tensor,
    shift: torch.Tensor,
    eps: float,
) -> torch.Tensor:
    return torch.empty_like(x)


@register_custom_op(
    op_name="triton_fused_rmsnorm_scale_shift_bitexact",
    mutates_args=[],
    fake_impl=_fake_norm_scale_shift,
)
def fused_rmsnorm_scale_shift_bitexact(
    x: torch.Tensor,
    weight: torch.Tensor,
    scale: torch.Tensor,
    shift: torch.Tensor,
    eps: float,
) -> torch.Tensor:
    """``norm(x) * (1 + scale) + shift``, bit-exact vs the eager chain."""
    batch, seq_len, hidden, tpr = _validate_rmsnorm_modulate(x, weight, scale, shift)
    out = torch.empty_like(x)
    with torch.cuda.device(x.device):
        _rmsnorm_scale_shift_kernel[(batch * seq_len,)](
            out,
            out,
            x,
            x,
            x,
            weight,
            scale,
            shift,
            seq_len,
            eps,
            D=hidden,
            TPR=tpr,
            WPR=tpr // 32,
            HAS_GATE=False,
            # num_warps must match the replicated kernel's warps-per-row:
            # larger blocks trigger pathological Triton layout conversions
            # in the fold stage (measured 25us -> 500us at num_warps=4).
            num_warps=max(tpr // 32, 1),
        )
    return out


def _fake_scale_residual_norm_scale_shift(
    residual: torch.Tensor,
    update: torch.Tensor,
    gate: torch.Tensor,
    weight: torch.Tensor,
    scale: torch.Tensor,
    shift: torch.Tensor,
    eps: float,
) -> Tuple[torch.Tensor, torch.Tensor]:
    return torch.empty_like(residual), torch.empty_like(residual)


@register_custom_op(
    op_name="triton_fused_scale_residual_rmsnorm_scale_shift_bitexact",
    mutates_args=[],
    fake_impl=_fake_scale_residual_norm_scale_shift,
)
def fused_scale_residual_rmsnorm_scale_shift_bitexact(
    residual: torch.Tensor,
    update: torch.Tensor,
    gate: torch.Tensor,
    weight: torch.Tensor,
    scale: torch.Tensor,
    shift: torch.Tensor,
    eps: float,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """``res = residual + gate * update; norm(res) * (1 + scale) + shift``.

    Returns ``(modulated, res)``, both bit-exact vs the eager pair + norm
    chain (and therefore vs the ``residual_gate_add_cuda`` fast path).
    """
    batch, seq_len, hidden, tpr = _validate_rmsnorm_modulate(
        residual, weight, scale, shift
    )
    if not (
        update.dtype == residual.dtype
        and update.device == residual.device
        and update.shape == residual.shape
        and update.is_contiguous()
        and _is_row_broadcast(gate, (batch, 1, hidden), residual.device)
    ):
        raise RuntimeError(
            "update must match residual; gate must be contiguous [B, 1, D] with the same dtype/device"
        )
    out = torch.empty_like(residual)
    res_out = torch.empty_like(residual)
    with torch.cuda.device(residual.device):
        _rmsnorm_scale_shift_kernel[(batch * seq_len,)](
            out,
            res_out,
            update,
            residual,
            gate,
            weight,
            scale,
            shift,
            seq_len,
            eps,
            D=hidden,
            TPR=tpr,
            WPR=tpr // 32,
            HAS_GATE=True,
            num_warps=max(tpr // 32, 1),
        )
    return out, res_out
